
let hours_worked = [7;7;2]