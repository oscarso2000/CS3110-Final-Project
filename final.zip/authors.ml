
let hours_worked = [50;65;38]
