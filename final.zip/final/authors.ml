
let hours_worked = [15;15;15]
